</main>
    <footer>
    <a href="index.php">page 1</a>
    <a href="page2.php">page 2</a>

    </footer>
<script src="js/app.js"></script>
</body>

</html>