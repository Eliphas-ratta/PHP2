<?php

require_once('haut_de_page.php')
?>
    
        <h1>Page 2</h1>
    
<?php

require_once('bas_de_page.php')
?>