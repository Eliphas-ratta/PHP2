<?php

$infos = [
    "fisrt_name" => "Samih",
    "name" => "HaBBANI",
    "age" => 33,
    "boy" => true
];

echo $info ["name"];

?>