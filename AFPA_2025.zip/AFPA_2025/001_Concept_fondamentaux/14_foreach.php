<?php

$names = ['Sam', 'Paul', 'Isa'];

foreach ($names as $key => $value) {
    echo $key . ' : ' . $value . '<br>';
}


foreach ($names as $value) {
    echo $value . '<br>';
}

?>