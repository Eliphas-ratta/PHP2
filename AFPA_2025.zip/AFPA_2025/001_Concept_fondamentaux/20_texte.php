<?php

    echo "<h1> Contenu depuis 20_text.php</h1>";


    ?>