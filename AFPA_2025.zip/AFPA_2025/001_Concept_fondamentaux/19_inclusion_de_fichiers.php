<?php


require_once("20_texte.php")
//require();
//include();
//include_once();
?>